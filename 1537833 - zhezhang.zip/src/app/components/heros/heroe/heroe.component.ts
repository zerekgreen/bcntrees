import { Component, OnInit } from '@angular/core';
import{ActivatedRoute} from '@angular/router'
//service
import{ HeroesService}from '../../../components/services/heroes.service'

@Component({
  selector: 'app-heroe',
  templateUrl: './heroe.component.html',
  styleUrls: ['./heroe.component.css']
})
export class HeroeComponent implements OnInit {

  id: any;
  heroe: any;
  constructor(
    private ActivatedRoute: ActivatedRoute,
    private heroesService: HeroesService
  ) {
   this.id = this.ActivatedRoute.snapshot.paramMap.get('id');
   }

  ngOnInit(): void {
this.heroe = this.heroesService.getHeroe(this.id)
console.log(this.heroe);
  }

}

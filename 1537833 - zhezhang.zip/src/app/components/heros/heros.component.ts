import { Component, OnInit } from '@angular/core';
//SERICE

import { HeroesService} from '../services/heroes.service';

@Component({
  selector: 'app-heros',
  templateUrl: './heros.component.html',
  styleUrls: ['./heros.component.css']
})
export class HerosComponent implements OnInit {

  heroesComp: any [];

  constructor(
    private heroService: HeroesService
  ) { }

  ngOnInit() {
    this.heroesComp = this.heroService.getHeroes();
    console.log(this.heroesComp);
  }

}

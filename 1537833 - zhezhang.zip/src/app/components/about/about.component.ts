import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  nombre = "Zerek Green"
  nombre1 = "wHo is hAvINg tHaT conversation"
  dinero = 555.40
  fecha: Date = new Date();
  percentage: number = 0.555;

  constructor() { }
 
  ngOnInit(): void {
  }

}

import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class HeroesService {
  heroesService:any[] = [
    {
      id: 0,
      nombre: "Kermes oak Galls",
      poder: "Wandering around the more overgrown corners of Montjuïc and other “wild” fringes of Barcelona, like the sunny slopes of Collserola, you may well come across Kermes oak, Quercus coccifera, an evergreen low growing oak found across the Mediterranean.",
      img: "assets/img/Kermes oak Galls.jpg"
    },
    {
      id: 1,
      nombre: "Mediterranean dwarf palm and Gaudí",
      poder: "Another example of how Gaudí found inspiration in nature. The iron railing of Casa Vicens in Gràcia, Barcelona based on the Mediterranean dwarf palm (Chamaerops humilis), Europe’s only native palm.",
      img: "assets/img/Mediterranean dwarf palm and Gaudí.jpg"
    },
    {
      id: 2,
      nombre: "Barcelona parakeet nest",
        poder: "A parakeet nest abandoned for the winter in a Plane tree on a Barcelona street. Some of these nests are huge, tottering perilously over the streets weighing more than a tonne, though this one is much smaller.",
      img: "assets/img/Barcelona parakeet nest.jpg"
    },
    {
      id: 3,
      nombre: "Lace bugs",
      poder: "The commonest tree by far in Barcelona is the London plane (Platanus x acerifolia), a hybrid of Turkish and American ancestors. It is tolerant of atmospheric pollution which it deals with by constantly shedding its flaky bark – itself a way its wild relatives combat parasites. Peel off their bark and you may find tiny Sycamore lace bugs (Corythucha ciliata), gorgeously intricate under the magnifying glass, although these pests suck on the tree’s sap and lead to its early death.",
      img: "assets/img/Lace bugs.jpg"
    },
    {
      id: 4,
      nombre: "The tallest palm tree in Barcelona",
      poder: "The tallest palm tree in Barcelona is considered to be a 27-metre which stands outside the Centre Cívic Can Verdaguer in Nou Barris. It is 119 years old is a Washingtonia robusta originally from Mexico-Calaifornia",
      img: "assets/img/The tallest palm tree in Barcelona.jpg"
    }
    ];
  constructor() {
    console.log("Service on");
   }

   getHeroes(){
     return this.heroesService;
   }

  getHeroe(id: any){
    let heroeTemp: any;
    for(let heroe of this.heroesService){
      if (+id == heroe.id){
        heroeTemp = heroe;
    
      }
  
    }
  return heroeTemp;
  }

buscarHeroes(texto: string){

let heroesBusqueda: any[]=[];
texto = texto.toLocaleLowerCase();
for(let heroe of this.heroesService){
  let nombre = heroe.nombre.toLocaleLowerCase();

  console.log(nombre.indexOf(texto));
  if (nombre.indexOf(texto) >= 0) {
    heroesBusqueda.push(heroe);
  }



/*if(texto == nombre){
  heroesBusqueda.push(heroe);
}*/


}
console.log(heroesBusqueda);
return heroesBusqueda;
}
}


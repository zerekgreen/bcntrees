import { Component, OnInit } from '@angular/core';

//service
import { YoutubeService} from "../../services/youtube.service";

//model
import {Video} from '../../Models/youtube.model';

import Swal from 'sweetalert2'

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {
  
  videos: any[] = [];

  constructor(
   private YoutubeService: YoutubeService
  ) { }

  ngOnInit(): void {
    this.YoutubeService.getVideos()
    .subscribe(resp =>{
      console.log(resp)
      this.videos.push(...resp.items);
    });
  }
verVideo(video: any){
Swal.fire({
  title: `<strong>${video.snippet.title}</strong>`,
  html:
  `<iframe 
  width="100%" height="315" 
  src="https://www.youtube.com/embed/${video.snippet.resourceId.videoId}" 
  title="YouTube video player" frameborder="0" 
  allow="accelerometer; autoplay; 
  clipboard-write; encrypted-media; 
  gyroscope; 
  picture-in-picture" allowfullscreen>
  </iframe>`
  
});
}
}
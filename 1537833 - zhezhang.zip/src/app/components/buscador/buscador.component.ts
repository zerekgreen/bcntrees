import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
//service
import{ HeroesService}from '../services/heroes.service'
@Component({
  selector: 'app-buscador',
  templateUrl: './buscador.component.html',
  styleUrls: ['./buscador.component.css']
})
export class BuscadorComponent implements OnInit {
texto: string;

heroesBusq: any[];
  constructor( 
    private ActivatedRoute: ActivatedRoute,
    private heroesService: HeroesService,
    ) { 
      this.texto = this.ActivatedRoute.snapshot.paramMap.get('texto');
  }

  ngOnInit()  {
    console.log(this.texto);
    this.heroesBusq = this.heroesService.buscarHeroes(this.texto)
  }

}

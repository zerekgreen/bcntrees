import { PersonalizadoPipe } from './personalizado.pipe';

describe('PersonalizadoPipe', () => {
  it('create an instance', () => {
    const pipe = new PersonalizadoPipe();
    expect(pipe).toBeTruthy();
  });
});

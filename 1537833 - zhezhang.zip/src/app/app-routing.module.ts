import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//components
import {HomeComponent} from './components/home/home.component';
import {AboutComponent} from './components/about/about.component';
import{HerosComponent}from './components/heros/heros.component';
import{HeroeComponent}from './components/heros/heroe/heroe.component';
import{BuscadorComponent}from './components/buscador/buscador.component';
import { BodyComponent } from './components/body/body.component';

const routes: Routes = [
  {path: '',component: HomeComponent},
  {path: 'home',component: HomeComponent},
  {path: 'body',component: BodyComponent},
  {path: 'heros',component: HerosComponent},
  {path: 'heroe/:id',component: HeroeComponent},
  {path:'about',component:AboutComponent},
  {path:'buscar/:texto',component:BuscadorComponent},
  {path: '**',component: HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

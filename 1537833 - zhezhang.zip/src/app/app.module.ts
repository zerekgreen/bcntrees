import { LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { BodyComponent } from './components/body/body.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { HerosComponent } from './components/heros/heros.component';
import { AboutComponent } from './components/about/about.component';
import { HeroeComponent } from './components/heros/heroe/heroe.component';
import { BuscadorComponent } from './components/buscador/buscador.component';
import { HttpClientModule} from "@angular/common/http";

//Config Idioma
import { registerLocaleData } from "@angular/common";
import localEs from "@angular/common/locales/es";
import { PersonalizadoPipe } from './pipes/personalizado.pipe';
import { VideoPipe } from './pipes/video.pipe';

registerLocaleData(localEs);

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    BodyComponent,
    FooterComponent,
    HomeComponent,
    HerosComponent,
    AboutComponent,
    HeroeComponent,
    BuscadorComponent,
    PersonalizadoPipe,
    VideoPipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
  ],
  providers: [
   { provide: LOCALE_ID,
    useValue: 'ES'}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams} from "@angular/common/http";
import {YoutubeResponse} from '../Models/youtube.model';

@Injectable({
  providedIn: 'root'
})
export class YoutubeService {

  private youtubeUrl = 'https://www.googleapis.com/youtube/v3';
  private apiKey = 'AIzaSyCDm71KfkgfdMIsQrU5PdDteI25Amqc2eM';
  private playlist = 'PL00o1OubAQPGn6GbTWqqyYqDFsBuA0FrX';
  constructor(
    private http: HttpClient,
  ) { }

  getVideos(){

    const urlVideos = `${this.youtubeUrl}/playlistItems`;
    const params = new HttpParams()
    .set('key',this.apiKey)
    .set('part','snippet')
    .set('playlistId',this.playlist)
    .set('maxResults','28')


    return this.http.get<YoutubeResponse>(urlVideos, {params})

  }

}